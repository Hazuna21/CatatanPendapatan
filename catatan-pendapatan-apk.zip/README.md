# Catatan Pendapatan (APK)

## Cara 1: tanpa Android Studio (GitHub, gratis)
1. Buat akun di github.com, lalu buat repositori baru (Private boleh).
2. Unggah seluruh isi folder ini ke repositori (Add file > Upload files).
   Jika folder `.github` tidak ikut terunggah: Add file > Create new file, ketik nama
   `.github/workflows/apk.yml`, lalu tempel isi file apk.yml dari zip ini.
3. Buka tab Actions > Build APK > Run workflow. Tunggu sekitar 5 menit sampai hijau.
4. Buka hasil build tersebut, unduh artifact `catatan-pendapatan-apk` (zip), ekstrak,
   lalu pindahkan `app-debug.apk` ke HP dan buka.
5. Android akan meminta izin "Instal aplikasi tidak dikenal" untuk pengelola file Anda. Izinkan.

## Cara 2: Android Studio
Pasang Node.js 20 dan Android Studio, lalu jalankan:
    npm install
    npx cap add android
    npx cap sync android
    npx cap open android
Di Android Studio pilih Build > Build APK(s).

## Mengubah aplikasi
Edit `www/index.html`, lalu build ulang. Data tersimpan di penyimpanan aplikasi di HP,
jadi memasang versi baru di atas yang lama tidak menghapusnya (selama appId tetap sama).
